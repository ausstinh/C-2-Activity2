﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    class Robin : Animal
    {
        public void Sing()
        {
            Console.WriteLine("Chirp chirp");
        }
    }
}

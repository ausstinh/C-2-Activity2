﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animal
{
    interface IMilkable
    {
        void MilkMe();
        void MakeBread();
    }
}
